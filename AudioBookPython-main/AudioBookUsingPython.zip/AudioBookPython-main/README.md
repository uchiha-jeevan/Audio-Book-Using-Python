# Audiobook-Project-with-Python
### What you can do through this code? ###
* You can convert text to speech from any PDF which uses the English language
* You can create audiobook and save that audiobook file as mp3. Isn't that amazing?

### Information regarding the GUI I used here ###
* [tkinter](https://docs.python.org/3/library/tkinter.html)

### The additional libraries I have used here to complete my project ###
* [pyttsx3](https://pypi.org/project/pyttsx3/)
* [PyPDF2](https://pypi.org/project/PyPDF2/)

### Owner 
Dolly

Install bellow Lib :

pip install -r requirements.txt
or 

pip install tk
pip install pyttsx3
pip install PyPDF2

Finally:
Python ProjectSourceCode.py
